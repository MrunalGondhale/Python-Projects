const express = require("express");
const {
  getCourseById,
  getCourses,
  CreateCourse,
  DeleteCourse,
  UpdateCourse,
  BlockCourse,
  getAllCourse,
  getPublished,
  putPublished,
} = require("../controllers/courseController.js");
const router = express.Router();
const { protect, authAdmin } = require("../middleware/authMiddleware.js");

router.route("/").get(protect, getCourses);
router.route("/allcourses").get( getAllCourse);

router.route("/:id").delete(authAdmin,DeleteCourse);
router.route("/block/:id").post(authAdmin,BlockCourse);
router.route('/published').get(protect,getPublished);
router.route('/:id').patch(putPublished);


router
  .route("/:id")
  .get(getCourseById)
  .delete(protect, DeleteCourse)
  .put(protect, UpdateCourse);
router.route("/create").post(protect, CreateCourse);

module.exports =router;