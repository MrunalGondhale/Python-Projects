const express = require('express');
const{ SubscribedCourse,getCourses }  =require("../controllers/myCoursesController.js");
const{ protect } = require("../middleware/authMiddleware.js");
const router = express.Router();

router.route("/").post(protect, SubscribedCourse);

router.route("/enrolled").get(protect, getCourses);


module.exports= router;


