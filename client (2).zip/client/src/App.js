import "./App.css";
import { BrowserRouter as Router, Route } from "react-router-dom";
import NavBar from "./components/NavBar";
import React, { useEffect, useState } from "react";
import ProfileScreen from "./screens/ProfileScreen/ProfileScreen";
import { useSelector } from "react-redux";
import ProtectedRoute from "./protectedRoute/ProtectedRoute"
import Home from "./screens/LandingPage/Home"
import Contact from "./screens/About/Contact"
import About from "./screens/About/About"
import SingleCourse from "./screens/mentorLandingPage/SingleCourse/SingleCourse";
import Courses from "./screens/mentorLandingPage/viewCourses/Courses";
import CreateCourse from "./screens/mentorLandingPage/SingleCourse/CreateCourse";
import ViewCourses from "./screens/AdminLandingPage/ViewCourses";
import ViewUsers from "./screens/AdminLandingPage/ViewUsers";
import Enrolled from "./screens/UserLandingPage/Enrolled";
import MentorList from "./screens/UserLandingPage/MentorList";
import View from "./screens/UserLandingPage/View";
import MentorCourses from "./screens/UserLandingPage/Menu/MentorCourses";
import CardDeta from "./screens/UserLandingPage/Menu/CardDeta";
import ResumeCourse from "./screens/UserLandingPage/Menu/ResumeCourse";
import PublishedCourses from "./screens/mentorLandingPage/viewCourses/PublishedCourses";
import ViewMentors from "./screens/AdminLandingPage/ViewMentors";
import homeImage from '../src/images/home.jpg'
function App() {
  const [search, setSearch] = useState("");
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;
  const [IsAuth, setIsAuth] = useState("")

  useEffect(() => {
    if(userInfo)
     {
       console.log(userInfo.role)
       setIsAuth(userInfo.role)}
   
  }, [userInfo])


  return (
   
    <Router>
      
      <NavBar  className='mb-5' setSearch={(s) => setSearch(s)}/>
      <div  className='mt-5'>
      
        <Route exact path="/profile"  component={ProfileScreen} />
        <ProtectedRoute exact path="/enrolled" IsAuth={IsAuth} role="User" component={() => (<Enrolled search={search}  />)} />
        <ProtectedRoute exact path="/unpublished" IsAuth={IsAuth} role="Mentor"  component={() => (<Courses search={search}  />)} />
        <ProtectedRoute exact path="/allcourses" IsAuth={IsAuth} role="Admin" component={() => (<ViewCourses search={search}  />)} />
        <ProtectedRoute exact path="/allusers" IsAuth={IsAuth} role="Admin" component={() => (<ViewUsers search={search}  />)} />
        <ProtectedRoute exact path="/allmentors" IsAuth={IsAuth} role="Admin" component={() => (<ViewMentors search={search}  />)} />

        <Route exact path="/" component={()=><Home />}></Route>
          <Route exact path="/about" component={About}></Route>
          <Route exact path="/contact" component={Contact}></Route>
          <Route exact path="/courses/:id"   component={SingleCourse} />
          <Route exact path="/createcourse"  component={CreateCourse} />

          <Route exact path="/viewcourse"   component={() => (<View search={search}  />)} />
          <Route exact path="/published"   component={() => (<PublishedCourses search={search}  />)} />
    <Route  exact path="/mentorlist"  component={() => (<MentorList search={search}  />)} />
    <Route  exact path="/previewcourse"  component={CardDeta}/>
    <Route  exact path="/resumeCourse/:id"  component={ResumeCourse}/>
    <Route  exact path="/mentorcourses/"  component={() => (<MentorCourses search={search}  />)}/>
      
   
      </div>

    </Router>
    
    
  );
}

export default App;
