import React from 'react'
import CommonHeader from '../LandingPage/home/CommonHeader'
function About() {
    return (
        <div>
              <CommonHeader title='ABOUT US'/>
        </div>
    )
}

export default About
