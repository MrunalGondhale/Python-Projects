import React from 'react'
import CommonHeader from '../LandingPage/home/CommonHeader'
function Contact() {
    return (
        <div>
              <CommonHeader title='CONTACT US'/>
        </div>
    )
}

export default Contact
