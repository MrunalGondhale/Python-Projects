import React, { useEffect } from "react";
import { Accordion, Badge, Button, Card } from "react-bootstrap";
import MainScreen from "../../components/MainScreen";
import { useHistory, withRouter } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import "../../bootstrap.min.css"
import { useDispatch, useSelector } from "react-redux";
import { deleteCourseAction, allCourses,blockCourseAction } from "../../actions/coursesActions";
import Loading from "../../components/Loading";
import ErrorMessage from "../../components/ErrorMessage";

function ViewCourses({search}) {
  const dispatch = useDispatch();
 const history =useHistory()
  const courseList = useSelector((state) => state.courseList);
  const { loading, error, courses } = courseList;

 

  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  const courseDelete = useSelector((state) => state.courseDelete);
  const {
    loading: loadingDelete,
    error: errorDelete,
    success: successDelete,
  } = courseDelete;

 
  useEffect(() => {
    if (!userInfo) {
    history.push("/");
  }
    dispatch(allCourses());
  
  }, [
    dispatch,
    userInfo,
    history,
    successDelete,

  ]);

  const deleteHandler = (id) => {
    if (window.confirm("Are you sure?")) {
      dispatch(deleteCourseAction(id));
    dispatch(allCourses());

    }
  };
  const blockHandler = (id) => {
    if (window.confirm("Are you sure?")) {
      dispatch(blockCourseAction(id));
    dispatch(allCourses());

    }
  };

  return (
    <MainScreen title={`Welcome Back ${userInfo && userInfo.name}..`}>
      {console.log(courses)}
      
      {error && <ErrorMessage variant="danger">{error}</ErrorMessage>}
      {errorDelete && (
        <ErrorMessage variant="danger">{errorDelete}</ErrorMessage>
      )}
      {loading && <Loading />}
      {loadingDelete && <Loading />}
      {courses &&
        courses
          .filter((filteredCourse) =>
            filteredCourse.title.toLowerCase().includes(search.toLowerCase())
          )
          .reverse()
          .map((course) => (
            <Accordion>
              <Card className="m-2" key={course._id}>
                <Card.Header className="d-flex">
                  <span
                    // onClick={() => ModelShow(course)}
                    style={{
                      color: "black",
                      textDecoration: "none",
                      flex: 1,
                      cursor: "pointer",
                      alignSelf: "center",
                      fontSize: 18,
                    }}
                  >
                    <Accordion.Toggle
                      as={Card.Text}
                      variant="link"
                      eventKey="0"
                    >
                      {course.title}
                    </Accordion.Toggle>
                  </span>

                  <div>
                    <Button onClick={()=>blockHandler(course._id)}>Block</Button>
                    <Button
                      variant="danger"
                      className="mx-2"
                      onClick={() => deleteHandler(course._id)}
                    >
                      Delete
                    </Button>
                  </div>
                </Card.Header>
                <Accordion.Collapse eventKey="0">
                  <Card.Body>
                    <h4>
                      <Badge variant="success">
                        Category - {course.category}
                      </Badge>
                    </h4>
                    <blockquote className="blockquote mb-0">
                      <ReactMarkdown>{course.content}</ReactMarkdown>
                      <footer className="blockquote-footer">
                        Created on{" "}
                        <cite title="Source Title">
                          {course.createdAt.substring(0, 10)}
                        </cite>
                      </footer>
                    </blockquote>
                  </Card.Body>
                </Accordion.Collapse>
              </Card>
            </Accordion>
          ))}
    </MainScreen>
  );
}

export default withRouter(ViewCourses);