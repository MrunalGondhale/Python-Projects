import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  listAllMentors,
  deleteUserAction,
  blockUserAction,
} from "../../actions/userActions";
import images from "../../images/images.png";
import { Button, Card } from "react-bootstrap";
import { Link, useHistory } from "react-router-dom";

function ViewMentors({ search }) {
  const dispatch = useDispatch();
  const history = useHistory()
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  const userDelete = useSelector((state) => state.userDelete);
  const {
    loading: loadingDelete,
    error: errorDelete,
    success: successDelete,
  } = userDelete;
  const mentorList = useSelector((state) => state.mentorList);
  const { users } = mentorList;

  useEffect(() => {
    if (!userInfo) {
      history.push("/");
    }

    dispatch(listAllMentors());
  }, [dispatch, userInfo, history, successDelete]);
  const deleteHandler = (id) => {
    if (window.confirm("Are you sure?")) {
      dispatch(deleteUserAction(id));
    dispatch(listAllMentors());

    }
  };
  const blockHandler = (id) => {
    if (window.confirm("Are you sure?")) {
      dispatch(blockUserAction(id));
    dispatch(listAllMentors());

    }
  };

  return (
    <div className="row">
      {users &&
        users
          .filter((filtereduser) =>
            filtereduser.name.toLowerCase().includes(search.toLowerCase())
          )
          .map((user) => (
            <div className="col-md-4">
              <Card>
                <Card.Img variant="top" src={images} />
                <Card.Body>
                  <Card.Title>
                    <strong>{user.name}</strong>
                  </Card.Title>
                  <Card.Text>
                    <h5>{user.email}</h5>
                  </Card.Text>
                  <Link to="/allmentors">
                    <td>
                      <Button id="block" onClick={() => blockHandler(user._id)}>
                        Block{" "}
                      </Button>
                      <Button
                        variant="danger"
                        className="mx-2"
                        onClick={() => deleteHandler(user._id)}
                      >
                        Delete{" "}
                      </Button>{" "}
                    </td>
                  </Link>
                </Card.Body>
              </Card>
            </div>
          ))}

    </div>
  );
}

export default ViewMentors;
