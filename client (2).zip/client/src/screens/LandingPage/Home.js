import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import ImageSlider from './home/ImageSlider';
import Card from './home/Card'
import Middle from './home/Middle';
import Heading from './home/Heading'
import react from '../../images/teach.jpg'
import './home.css'
import Numbers from './home/Numbers';



function Home() {
    return (
        <div >
            <div>
                <ImageSlider /> 
            </div>
            <div>
                <Heading /> 
            </div>
            <div className='container cardrow'>
                <div className='row p-0 '>
                    <div className=' col-md-3'>
                        <div className='m-2'>
                            <Card img={react} title="card title" cardtext="Some quick example text to " viewmore="Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus
                        terry .">
                            </ Card>
                        </div>
                    </div>
                    <div className=' col-md-3'>
                        <div className='m-2'>
                            <Card img={react} title="card title" cardtext="Some quick example text to " viewmore="Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus
                        terry .">
                            </ Card>
                        </div>
                    </div>
                    <div className='col-md-3'>
                        <div className='m-2'>
                            <Card img={react} title="card title" cardtext="Some quick example text to " viewmore="Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus
                        terry .">
                            </ Card>
                        </div>
                    </div>
                    <div className=' col-md-3'>
                        <div className='m-2'>
                            <Card img={react} title="card title" cardtext="Some quick example text to " viewmore="Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus
                        terry .">
                            </ Card>
                        </div>
                    </div>
                </div>{/* done */}
            </div>

            <div className=' my-3'>
                <Middle />
            </div>

            <div className=' my-3' >
                <Numbers />
            </div>

        </div>

    )
}

export default Home
