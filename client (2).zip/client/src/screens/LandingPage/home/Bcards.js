import React from 'react'
import {Button}  from 'react-bootstrap'
import {Link} from 'react-router-dom'

function Bcards(props) {
    return (
        <div className='border' >
                <img className="card-img-top p-auto m-auto" src={props.imag} alt='abcd' />
                <div className="card-body ">               
                <h5 className="card-title d-flex justify-content-center "><strong>{props.category}</strong></h5>
                <h5 className='d-flex justify-content-center text-dark'>{props.title}</h5>
                <h5 className= 'd-flex justify-content-center text-dark'>Conducted By : <strong>{props.mentorname}</strong></h5>
                <Button className='mt-2 mr-2'  variant='outline-success' onClick={props.onclick}>ENROLL</Button>
                <Link to='/previewcourse' >
                <Button className='mt-2 ml-3' variant='outline-info'>PREVIEW</Button>
               </Link>
               </div>
               
               
        </div>
    )
}

export default Bcards

 {/* <Bcards
                imag={react}
                title={course.title}
                category={course.category}
                mentorname={course.user.name}
                viewmore={course.content}
                onclick={(e) => {
                  dispatch(enrollCourse(course._id));
                }}
              >
                {console.log(course.title)}
              </Bcards> */}
