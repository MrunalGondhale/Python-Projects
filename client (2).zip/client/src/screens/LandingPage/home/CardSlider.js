import React, {useState} from 'react';
import {Carousel} from 'react-bootstrap';
import Category from './Category';
import './cardslider.css'

function CardSlider() {

    const [index, setIndex] = useState(0);
    const handleSelect = (selectedIndex, e) => {
      setIndex(selectedIndex);
    };
  
    return (
     
        <Carousel className='position-relative' activeIndex={index} onSelect={handleSelect}>

          <Carousel.Item>
              <Category />
             
          </Carousel.Item>

          <Carousel.Item>
              <Category />
              
          </Carousel.Item>

          <Carousel.Item>
              <Category />
              
          </Carousel.Item>

        </Carousel>
    )
}

export default CardSlider
