import React, { useState } from 'react'
import './category.css';
import { Button, Collapse } from 'react-bootstrap';
function Category(props) {

  const [open, setOpen] = useState(false);

  return (
    <div className='row'>
      <div className='col-md-2'>
        <div className="cardss my-5">
          <div className="card-body">
            <h5 className="card-title my-5">{props.title}</h5>
            <Button variant='outline-info'>VIEW MORE</Button>
          </div>
        </div>
      </div>
      <div className='col-md-2'>
        <div className="cardss my-5">
          <div className="card-body">
            <h5 className="card-title my-5">{props.title}</h5>
            <Button variant='outline-info'>VIEW MORE</Button>
          </div>
        </div>
      </div>
      <div className='col-md-2'>
        <div className="cardss my-5">
          <div className="card-body">
            <h5 className="card-title my-5">{props.title}</h5>
            <Button variant='outline-info'>VIEW MORE</Button>
          </div>
        </div>
      </div>
      <div className='col-md-2'>
        <div className="cardss my-5">
          <div className="card-body">
            <h5 className="card-title my-5">{props.title}</h5>
            <Button variant='outline-info'>VIEW MORE</Button>
          </div>
        </div>
      </div>
      <div className='col-md-2'>
        <div className="cardss my-5">
          <div className="card-body">
            <h5 className="card-title my-5">{props.title}</h5>
            <Button variant='outline-info'>VIEW MORE</Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Category
