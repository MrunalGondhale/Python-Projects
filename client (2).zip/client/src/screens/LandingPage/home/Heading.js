import React from 'react'
import './Heading.css';
import {Button} from 'react-bootstrap';
function Heading() {
    return (
        <div>
            <div className='row my-4 mx-0 '>
                    <h1 className='col-md-8 ml-auto mr-5 text-dark text-right'><strong>RECOMMENDATIONS FOR YOU !!</strong> </h1>
                   
                  
                </div>
        </div>
    )
}

export default Heading
