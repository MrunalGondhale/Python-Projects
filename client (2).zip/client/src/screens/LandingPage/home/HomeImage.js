import React from 'react'
import './homei.css'
import {Image} from 'react-bootstrap'
import homeImage from '../../../images/home_image.jpg'
function HomeImage() {
    return (
        <div className='box' >
            <Image src={homeImage} className='homeimage fluid' alt='homeimage'></Image>
        </div>
    )
}

export default HomeImage
