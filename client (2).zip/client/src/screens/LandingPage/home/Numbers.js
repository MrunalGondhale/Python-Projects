import React from 'react'
import './Numbers.css'

function Numbers() {
    return (
        <div className='container numbers'>
            <div className='row'>
                <div  className='col-sm-4'>
                    <div className='m-2 p-2'>
                        <h1 className='text-center text-success'><strong>1566</strong></h1>
                        <h2 className='text-center P-2'><strong>COURSES</strong></h2>
                    </div>
                </div>
                <div  className='col-sm-4'>
                    <div className='m-2 p-2'>
                        <h1 className='text-center text-success'><strong>1566</strong></h1>
                        <h2 className='text-center P-2'><strong>MENTORS</strong></h2>
                    </div>
                </div>
                <div  className='col-sm-4'>
                    <div className='m-2 p-2'>
                        <h1 className='text-center text-success'><strong>1566</strong></h1>
                        <h2 className='text-center P-2'><strong>ENROLLMENTS</strong></h2>
                    </div>
                </div>

            </div>
        </div>
    )
}

export default Numbers
