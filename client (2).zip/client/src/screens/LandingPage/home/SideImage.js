import React from 'react'
import home from '../../../images/lang.jpg';
import './homeimage.css';
import { Form, FormControl, Button } from 'react-bootstrap';
function SideImage() {
    return (
        <div className='row'>           
            <div className=' texts text-center m-0 p-0 text-light py-5 col-md-6'>
                <h3 className='my-5 '> STUDY ANY TOPIC, ANYTIME</h3>
                <h1> Just Learn</h1>
                <Button variant="outline-success">Register as Learner</Button> 
                </div>
            <div className='sideimage m-0 p-0 col-md-6'>
                <img src={home} alt=" laptop" />
            </div>

        </div>

    )
}

export default SideImage
