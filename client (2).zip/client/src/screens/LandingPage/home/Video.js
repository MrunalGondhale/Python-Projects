import React from 'react'
import './video.css';
function Video() {
    return (
        <div className='sizer m-auto'>
            <div className="embed-responsive embed-responsive-16by9 ">
            <iframe width="300" height="280" src="https://www.youtube.com/embed/NKAanYdic9Q" title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" ></iframe>
            </div>
        </div>
    )
}

export default Video
