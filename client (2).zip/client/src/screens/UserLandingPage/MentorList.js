import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { listAllMentors } from "../../actions/userActions"
import { listMentorCourses } from "../../actions/coursesActions";
import images from '../../images/teach.jpg';
import { Button,Card } from 'react-bootstrap';
import { Link,useHistory } from 'react-router-dom'
import CommonHeader from "../LandingPage/home/CommonHeader";


function MentorList({search}) {
    const dispatch = useDispatch();
  const history = useHistory();

    const mentorList = useSelector((state) => state.mentorList);
    const { users } = mentorList;
    const userLogin = useSelector((state) => state.userLogin);
    const { userInfo } = userLogin;
   
    
    useEffect(() => {
        if (!userInfo) {
            history.push("/");
          }
        dispatch(listAllMentors());

    }, [
        dispatch

    ]);

    return (
        <div className=''>
            <CommonHeader title='MENTORS AVAILABLE'/>
        <div className='container mt-4 p-4'>
        <div className=' row'>
                    {
                        users &&
                        users
                        .filter((filtereduser) =>
                        filtereduser.name.toLowerCase().includes(search.toLowerCase())
                      )
                            .map((user) => (
                                <div className='col-md-3'>
                                    <div className='m-2'>
                                    <Card>
                                        <Card.Img variant="top" src={images} />
                                        <Card.Body className=''>
                                            <Card.Title className='text-center mb-2'><strong>{user.name}</strong></Card.Title>
                                            <div className='text-center mt-4'>
                                            <Link  to='/mentorcourses'>
                                            <Button  variant="outline-success" onClick={e => { dispatch(listMentorCourses(user._id)) }}>View My Courses</Button>
                                           </Link>
                                           </div>
                                        </Card.Body>
                                    </Card>
                                    </div>
                                   
                                </div>
                                
                            ))}
               
        </div>
        </div>
        </div>
    )
}

export default MentorList
