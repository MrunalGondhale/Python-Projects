import React from 'react'
import { Button } from 'react-bootstrap'
function CardDeta(props) {

    return (
        <div className='m-5'>
            <div className="card m-5" >

                <div className="card-body">

                    <p className="card-text">hellooooxt</p>
                    <h3 className="card-title">hellooooname</h3>
                    <p className="card-text">hellooooxt</p>

                    <Button variant="primary"  >
                        Start Now
                    </Button>
                </div>
            </div>
        </div>

    )
}

export default CardDeta;
