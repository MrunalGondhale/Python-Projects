import React, { useEffect, useState } from "react";
import { Button,Table} from "react-bootstrap";
import {  withRouter } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { publishedCourseAction,PublishedList} from "../../../actions/coursesActions";
import './Courses.css'
function PublishedCourses({ history, search }) {
  const dispatch = useDispatch();

  const [show, setShow] = useState("true");
 

  const publishedList = useSelector((state) => state.publishedList);
  const { loading, error, courses } = publishedList;

  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  useEffect(() => {
    dispatch(PublishedList());
    if (!userInfo) {
      history.push("/");
    }
  }, [dispatch, history, userInfo]);

  const publishedHandler = (id) => {
    if (window.confirm("Successfully Published")) {
      dispatch(publishedCourseAction(id));
      dispatch(PublishedList());
    }
  };
  return (
    <div>
       <h2 className='createcourseheader py-3 text-center text-light'><strong> PUBLISHED COURSES</strong></h2>
      
          <div className='background container mt-4'>
            <div className='row'>
     
      {courses &&
        courses
          .filter((filteredCourse) =>
            filteredCourse.title.toLowerCase().includes(search.toLowerCase())
          )
          .reverse()

          .map((course) => (
            <div className="col-md-4 py-md-4 " data-aos="zoom-out" data-aos-delay="100">
            <div className="flip-card m-auto">
              <div className="flip-card-inner m-auto">
                <div className="flip-card-front bg-light">
                  <h1 className="mt-5">{course.title}</h1>
                   <p className="mt-5">Counducted By {userInfo.name}</p> 
                  {/* <p>{course.category}</p> */}
                </div>
                <div className="flip-card-back">
                  {course.content}
                  <div className="mt-5">

                  <Button
                   variant='outline-success'
                    onClick={() => setShow(true)}
                    onClick={() => {
                      publishedHandler(course._id);
                    }}
                  >
                    PUBLISH
                  </Button>
                  </div>
                </div>
              </div>
            </div>
            </div>
           
          ))}
          </div>
      
    </div>
    </div>
  );
}

export default withRouter(PublishedCourses);
