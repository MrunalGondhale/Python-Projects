const express = require("express");
const {
  getCourseById,
  getCourses,
  CreateCourse,
  DeleteCourse,
  UpdateCourse,
  BlockCourse,
  getAllCourse,
  getMentorCourses,
} = require("../controllers/courseController.js");
const router = express.Router();
const { protect, authAdmin } = require("../middleware/authMiddleware.js");

router.route("/").get(protect, getCourses);
router.route("/allcourses").get( getAllCourse);
router.get("/mentorcourses/:id", getMentorCourses);

router.route("/block/:id").post(authAdmin,BlockCourse);


router
  .route("/:id")
  .get(getCourseById)
  .delete(protect, DeleteCourse)
  .put(protect, UpdateCourse);
router.route("/create").post(protect, CreateCourse);

module.exports =router;