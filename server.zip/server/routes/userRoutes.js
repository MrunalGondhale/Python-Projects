const express = require("express");
const{
  authUser,
  registerUser,
  updateUserProfile,
  BlockUser,
  delUser,
  getUsers,
  enrolledCourses,
  getAllMentors,
} =require("../controllers/userController.js");
const{ protect, authAdmin } = require("../middleware/authMiddleware.js");
const router = express.Router();

router.route("/").post(registerUser);
router.post("/login", authUser);
router.route("/profile").post(protect, updateUserProfile);
router.route("/block/:id").patch(BlockUser);
router.route('/:id').delete(authAdmin,delUser);
router.route('/:id').patch(protect,enrolledCourses)

router.get("/getmentors", getAllMentors);

router.route('/users').get(authAdmin, getUsers) 


module.exports= router;